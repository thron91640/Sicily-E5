CHANGELOG
=========

4.2.0
-----

 * added the component
