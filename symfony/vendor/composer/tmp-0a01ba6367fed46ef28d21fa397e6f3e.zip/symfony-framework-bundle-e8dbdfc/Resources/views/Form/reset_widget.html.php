<?php echo $view['form']->block($form, 'button_widget', ['type' => $type ?? 'reset']) ?>
