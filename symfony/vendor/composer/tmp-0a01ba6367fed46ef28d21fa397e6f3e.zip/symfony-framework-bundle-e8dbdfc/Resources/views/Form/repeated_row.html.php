<?php echo $view['form']->block($form, 'form_rows') ?>
