UPGRADE FROM 2.2 to 2.3
=======================

* Deprecated using short namespace alias syntax in favor of ::class syntax.
